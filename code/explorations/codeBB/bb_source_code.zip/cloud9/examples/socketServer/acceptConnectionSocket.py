# Socket example
# ==> accept incoming connection on socket

import socket
import sys
 
HOST = ''   # Symbolic name meaning all available interfaces
PORT = 8888 # Arbitrary non-privileged port
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Socket created'
 
try:
    s.bind((HOST, PORT))
except socket.error , msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
     
print 'Socket bind complete'
 
s.listen(10)
print 'Socket now listening'

# Keep the server running non stop
while 1:
    # Wait to accept a connection - blocking call
    conn, addr = s.accept()
     
    # Display client information
    print 'Connected with ' + addr[0] + ':' + str(addr[1])
    
    # Keep talking to client
    data = conn.recv(1024)
    reply = 'OK...'+data
    if not data:
        break
    
    conn.sendall(reply)

conn.close()
s.close()