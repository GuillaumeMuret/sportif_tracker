import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Calendar;

/*
 * Retrieve data broadcasted by the Bluefruit element
 */

public class Scan {
    private static final int PAYLOAD_LENGTH_POSITION = 17;
    public static final int UUID_START_POSITION = 25;
    private static final int UUID_END_POSITION = 39;
    private static final int DATA_TYPE_POSITION = 39;
    private static final int DATA_POSITION = 41;
    private static final String ADVERTISING_PAYLOAD_LENGTH = "1A";
    
    LinkedList<String> linkedRawData = new LinkedList<String>();
    
    
    class SendCommand extends Thread{
        public Process processConfigureSniffer = null;
        String configSnifferError, beaconRawData;
        List<String> cmd = new ArrayList<String>();
        
        public void run(){

            try{
                //Build command 
                cmd.add("/var/lib/cloud9/examples/getRawDataBeacon.sh");
                //Add arguments
                System.out.println(cmd);
        
                //Run macro on target
                ProcessBuilder pb = new ProcessBuilder(cmd);
                pb.redirectErrorStream(true);
                Process process = pb.start();
                BufferedReader brSniffer_error = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()));
                BufferedReader brSniffer_input = new BufferedReader(
                        new InputStreamReader(process.getInputStream()));
                while ((beaconRawData = brSniffer_input.readLine()) != null){
                    handle(beaconRawData);
                }
                while ((configSnifferError = brSniffer_error.readLine()) != null){
                }
                
                if (process.waitFor()==0){
                    System.exit(0);
                }
                
                System.err.println(cmd);
                System.err.println(configSnifferError.toString());
                System.exit(1);
                
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    
    public void handle(String rawData){
        String[] rawDataArray = rawData.split(" ");
        String[] deviceUuidArray = new String[UUID_END_POSITION-UUID_START_POSITION];
        String[] dataTypeArray = new String[2];
        String[] dataArray = new String[2];
        int rawDataArrayLength = rawDataArray.length;
        int deviceUuidArrayLength = deviceUuidArray.length;
        int dataTypeArrayLength = dataTypeArray.length;
        int dataArrayLength = dataArray.length;
        String deviceUuid, dataType, data;
        
        try{
            /*for(int i=0; i<rawDataArrayLength; i++){
                System.out.print(rawDataArray[i]);
            }*/

            if(rawDataArray[0].equals(">")){
                linkedRawData = new LinkedList<String>();
                
                for(int i=1; i<rawDataArrayLength; i++){
                    linkedRawData.add(rawDataArray[i]);
                }
            }else{
                for(int i=0; i<rawDataArrayLength; i++){
                    linkedRawData.add(rawDataArray[i]);
                }
            }
            linkedRawData.remove(43);
            linkedRawData.remove(42);
            linkedRawData.remove(21);
            linkedRawData.remove(20);

            if(linkedRawData.size()==45){
                if(linkedRawData.get(PAYLOAD_LENGTH_POSITION).equals(ADVERTISING_PAYLOAD_LENGTH)){
                    for(int i=UUID_START_POSITION;i<UUID_END_POSITION;i++){
                        deviceUuidArray[i-UUID_START_POSITION]=linkedRawData.get(i);
                    }
                    for(int i=DATA_TYPE_POSITION;i<=DATA_TYPE_POSITION+1;i++){
                        dataTypeArray[i-DATA_TYPE_POSITION]=linkedRawData.get(i);
                    }
                    for(int i=DATA_POSITION;i<=DATA_POSITION+1;i++){
                        dataArray[i-DATA_POSITION]=linkedRawData.get(i);
                    }
                    dataType = Arrays.toString(dataTypeArray);
                    deviceUuid = Arrays.toString(deviceUuidArray);
                    data = Arrays.toString(dataArray);
                    
                    System.out.print("\n");
                    System.out.println(Calendar.getInstance().getTime().toString());
                    System.out.println(dataType);
                    System.out.println(deviceUuid);
                    System.out.println(data);
                }
            }
        
        }catch(Exception e){
        }
    }
    
    
    public static void main(String args[]) {
        SendCommand sendCommand = new Scan().new SendCommand();
        
        try{
            sendCommand.start();
            
        }catch(Exception e){
            e.printStackTrace();
            System.exit(-1);
        }
    }
}