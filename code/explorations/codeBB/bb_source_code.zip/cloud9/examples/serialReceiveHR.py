import Adafruit_BBIO.UART as UART
import serial
import time
import sys, os

UART.setup("UART1")

ser = serial.Serial(port = "/dev/ttyO1", baudrate = 9600,
               parity=serial.PARITY_NONE,
               stopbits=serial.STOPBITS_ONE,
               bytesize=serial.EIGHTBITS,
               timeout=1)
               
os.system('/var/lib/cloud9/examples/uartConfig.sh')

print("\r\nLaunch executed\r\n")

try:
    ser.close()
    ser.open()
except Exception as e:
    print("error trying to open serial port:"+str(e))
    exit()
    
if ser.isOpen():
    try:
        ser.flushInput()
        ser.flushOutput()
    except Exception.e1:
        print("error flushing buffers")
        
    ser.write("I'm BeagleBone Black !\n")
    i=0
    while True:
        serialData=ser.read()
        if len(serialData)>0 and serialData!='':
            print(serialData)
else:
    print("Cannot read from serial port")
        
ser.close()