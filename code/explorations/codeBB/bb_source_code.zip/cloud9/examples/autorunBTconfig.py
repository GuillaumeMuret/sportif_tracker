# Script to be lauched when BeagleBone is powered up
# This script configures the Bluetooth dongle in order to make
# BB discoverable

import subprocess
import pexpect

#bt=pexpect.spawn("bluetoothctl", echo=False)
#bt.send("discoverable on\n")

subprocess.call(['sudo', 'hciconfig', 'hci0', 'up'])
subprocess.call(['sudo', 'hciconfig', 'hci0', 'piscan'])
subprocess.call(['hciconfig'])