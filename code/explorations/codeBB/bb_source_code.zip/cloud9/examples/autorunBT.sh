# Script to be lauched when BeagleBone is powered up
# This script configures the Bluetooth dongle in order to make
# BB discoverable

#!/bin/bash
sudo systemctl start bluetooth

sleep 1

echo 'power on' | bluetoothctl
echo 'discoverable on' | bluetoothctl