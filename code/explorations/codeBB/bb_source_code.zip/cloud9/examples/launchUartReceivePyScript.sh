#!/bin/bash

echo "$(python /var/lib/cloud9/examples/serialReceiveHR.py)"