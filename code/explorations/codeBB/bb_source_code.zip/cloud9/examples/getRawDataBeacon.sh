# Script to configure BLE sniffer

#!/bin/bash

sudo hciconfig hci0 down
sleep 1
sudo hciconfig hci0 up
sudo hcitool lescan --duplicates &
sudo hcidump --raw