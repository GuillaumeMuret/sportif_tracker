# UART config pins

#!/bin/bash
config-pin P9.21 uart
sleep 1
config-pin P9.22 uart
sleep 1
config-pin P9.24 uart
sleep 1
config-pin P9.26 uart 