#!/bin/sh

print_usage()
{
cat << EOF
Reflash binaries to the module

Usage $0 <binary>

EOF
}

if [[ "$#" -lt 1 ]]; then
    print_usage;
    exit 1
fi


FW_BIN=$1

if [[ "$PRG" = "swd" ]]; then
OPENOCD=openocd-0.10.0
OPENOCD_CFG=oc8-r-swd.cfg
OPENOCD_CFG_DIR=../tools
else
OPENOCD=openocd-0.8.0
OPENOCD_CFG=oc8-r.cfg
OPENOCD_CFG_DIR=../tools
fi

FW_ERASE_ADDR=0x00400000
FW_ADDR=0x00000000
FW_SIZE=0x00080000

[ -f $FW_BIN ] || echo "$FW_BIN not found"

$OPENOCD -s $OPENOCD_CFG_DIR -f $OPENOCD_CFG \
	-c "init;halt;reset init;halt;sleep 250;flash probe 0;" \
	-c "flash erase_address $FW_ERASE_ADDR $FW_SIZE;" \
	-c "flash write_bank 0 $FW_BIN $FW_ADDR;" \
	-c "clear_gpbr_boot_reg; reset run;shutdown"
