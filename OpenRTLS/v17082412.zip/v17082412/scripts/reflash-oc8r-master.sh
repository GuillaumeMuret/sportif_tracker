#!/bin/sh

./reflash-oc8r-full.sh ../binaries/oc8r-master_eval.bin
