#!/bin/sh

print_usage()
{
cat << EOF
Reflash binaries to the module

Usage $0 <binary>

EOF
}

if [[ "$#" -lt 1 ]]; then
    print_usage;
    exit 1
fi


FW_BIN=$1


if [[ "$PRG" = "swd" ]]; then
OPENOCD=openocd-0.10.0
OPENOCD_CFG=at91sam4s-swd.cfg
OPENOCD_CFG_DIR=../tools
else
OPENOCD=openocd-0.8.0
OPENOCD_CFG=tagkiwi-sam4s.cfg
OPENOCD_CFG_DIR=../tools
fi


ERASE_ADDR=0x00400000
ERASE_SIZE=0x00020000

FW_ADDR=0x00000000

[ -f $BOOTLOADER_BIN ] || echo "$BOOTLOADER_BIN not found"
[ -f $FWLOADER_BIN ] || echo "$FWLOADER_BIN not found"
[ -f $FW_BIN ] || echo "$FW_BIN not found"

$OPENOCD -s $OPENOCD_CFG_DIR -f $OPENOCD_CFG \
	-c "init;halt;reset init;halt;sleep 250;flash probe 0;" \
	-c "flash erase_address $ERASE_ADDR $ERASE_SIZE;" \
	-c "flash write_bank 0 $FW_BIN $FW_ADDR;" \
	-c "clear_gpbr_boot_reg; reset run;shutdown"
