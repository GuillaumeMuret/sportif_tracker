#!/bin/sh

./reflash-oc8r-full.sh ../binaries/oc8r-anchor_eval.bin
