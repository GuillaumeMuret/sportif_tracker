#!/usr/bin/python

from __future__ import print_function

import asynchat
import asyncore
import socket
import threading
import json
import signal
import sys
import pprint
from time import sleep
import zlib
from struct import *
from collections import OrderedDict
import subprocess
import os

import config
from operator import contains

anchors = {}


def doSVC(host, port, msg):
  s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
  s.connect((host, port))
  s.send(msg)
  sleep(0.5)
  data = s.recv(1024)
  s.close()
  return data

def read_in_chunks(file_object, chunk_size=512):
    while True:
        data = file_object.read(chunk_size)
        if not data:
            break
        yield data

class SVCClient(asynchat.async_chat):
    
    def __init__(self, host, port):
        asynchat.async_chat.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect( (host, port) )
        self.set_terminator('\n')

        self.buffer = []
        self.jsonmsg = []

    def collect_incoming_data(self, data):
        self.buffer.append(data)
 
    def found_terminator(self):
        msg = ''.join(self.buffer)
        cmds = msg.split('\n')
        for cmd in cmds:
            try:
                resp = json.loads(cmd)
            except ValueError as err:
                print('Failed:' + cmd)
                print (err)
                return
            else:
                print('Received:' + cmd)
                self.jsonmsg.append(resp)

        self.buffer = []    

    def request(self, cmd):
        req = '{"command":"'+cmd+'"}'
        print ('Sent:'+ req)
        self.jsonmsg = []
        self.push(req + '\n')
        
        timeout = 20
        while(timeout > 0):
            timeout = timeout - 1
            for resp in self.jsonmsg:
                if resp["response"] == cmd:
                    return resp
            sleep(0.5)    
            
    def request_with_id(self, cmd, id):
        req = '{"command":"'+cmd+'","id":"' + id + '"}'
        print ('Sent:'+ req)
        self.jsonmsg = []
        self.push(req + '\n')
        
        timeout = 20
        while(timeout > 0):
            timeout = timeout - 1
            for resp in self.jsonmsg:
                if resp["response"] == cmd:
                    if "status" in resp and resp["status"] == "in progress":
                        continue;
                    return resp
            sleep(0.5)    

    def request_message(self, cmd, msg):
        print ('Sent:'+ msg)
        self.jsonmsg = []
        self.push(msg + '\n')
        
        timeout = 20
        while(timeout > 0):
            timeout = timeout - 1
            for resp in self.jsonmsg:
                if resp["response"] == cmd:
                    return resp
            sleep(0.5)    

    def send_datapacket(self, data, timeout = 20):
        self.jsonmsg = []
        self.push(data)
        while(timeout > 0):
            timeout = timeout - 1
            for resp in self.jsonmsg:
                if 'status' in resp:
					if resp['status'] == "ok":
						return 1
					else:
						return 0
                elif 'crc' in resp:
					return 1
            sleep(0.1)    


def show_fw_desc_list(cl):
    resp = cl.request("listFwDesc");
    if(resp and len(resp)<2):
        print ("No Fw Descriptions found")

    print ("\n\nFollowing FW descriptions have been found")
    for desc in resp["fwDesc"]:
        if desc["flags"] == "0x00000000":
            print (str(desc["id"]) + "\tInvalid")
        else:
            print (str(desc["id"]), end="\t")
            print (str(desc["flags"]), end="\t")
            print (str(desc["hwVersion"]), end="\t")
            print (str(desc["target"]), end="\t")
            print (str(desc["addr"]), end="\t")
            print (str(desc["size"]), end="\n")

    print ("\n\n")


def send_firmware(filename, fwid):
	
	encfile = filename + ".aes"
	
	resp = client.request_with_id("removeFwDesc", str(fwid))
	
	fj = open(filename+'.json','r')
	msg = fj.read(1024)
	fj.close()
    
	blockcnt = 0

	fh = open(filename+'.hdr','rb')
	msgheader = fh.read(1024)
	fh.close()

	f = open(encfile,'rb')
	for block in read_in_chunks(f,512):

		retval = 0
		retries = 5

		while(retval == 0 and retries > 0):

			crcblock = zlib.crc32(block) % (1<<32)

			fwup_msg = bytearray()
			fwup_msg += b'ORFW'
			fwup_msg += msgheader
			fwup_msg += pack('IHH', crcblock, blockcnt, 0x00 )
			fwup_msg += block

			retries = retries - 1
			print ("Sending block " + str(blockcnt) + ' crc: '+ str(hex(crcblock)))
			if blockcnt is 0:
				retval = client.send_datapacket(fwup_msg,1000)
			else:
				retval = client.send_datapacket(fwup_msg)
		blockcnt = blockcnt + 1
			
	resp = client.request("saveFwDescList")
	
	if(resp and len(resp)<2):
		print ("Could not save the new Fw Desc List")

	show_fw_desc_list(client)


def exit_gracefully(signum, frame):
    plt.close('all')
    sys.exit(0)


if __name__ == '__main__':
	pp = pprint.PrettyPrinter(indent=4)

	doSVC(config.ip, config.port, "{\"command\":\"checkFwUpdate\"}\n")

	sleep(10)

	client = SVCClient(config.ip, config.port)    
	comm = threading.Thread(target=asyncore.loop)
	comm.daemon = True
	comm.start()

	show_fw_desc_list(client)

	send_firmware("binaries/rtls-tag-lite_antboot_fw2.bin", 1)
	send_firmware("binaries/rtls-anchor_eval_antboot_fw2.bin", 0)

	resp = client.request_with_id("bootFwDesc", '0')

	print ("\n\n") 
    

