# Socket client example in Python
# ==> Creates a new socket, connects to a remote server
# sends some data and receives a reply

import socket
import sys # system-specific parameters and functions

try:
    # Create a new TCP based socket
    # Socket properties :
        # Address family : AF_INET (IPv4)
        # Type : SOCK_STREAM (connection oriented TCP protocol)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
# Error handling
except socket.error, msg:
    print 'Failed to create socket. Error code : '+ str(msg[0]) + ', Error message : '+ msg[1]
    sys.exit()
    
print 'Socket Created'

host = 'www.google.com'
port = 80

# Get the IP address of the host
try:
    remote_ip = socket.gethostbyname(host)
except socket.gaierror:
    print 'Hostname could not be resolved. Exiting'
    sys.exit()
    
print 'IP adress of '+host+ ' is '+remote_ip

# Connect to remote server
s.connect((remote_ip, port))

print 'Socket connected to '+host+ ' on IP '+remote_ip

# HTTP command to fetch the mainpage of a website
message = "GET / HTTP/1.1\r\n\r\n"

try:
    # Send message via socket
    s.sendall(message)
except socket.error:
    print 'Send failed'
    sys.exit()

print 'Message sent successfully'

# Receive data
reply=s.recv(4096)

print reply

# Close socket
s.close()