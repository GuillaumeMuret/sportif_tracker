# WiFi Server
# Enable WiFi connection between BeagleBone and Tablette

