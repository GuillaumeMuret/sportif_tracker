Grove - IMU 10DOF is a combination of Grove - IMU 9DOF and Grove - Barometer Sensor (BMP180)

So we just have to import two packages and control them alone.
